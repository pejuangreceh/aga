<br>


<div class="row">

<div class="col-lg-12">
<div class="panel panel-default">

<div class="panel-heading"><svg class="glyph stroked male user "><use xlink:href="#stroked-male-user"/></svg>
<a href="<?php echo base_url();?>list_ticket/ticket_list" style="text-decoration:none">Profile</a></div>
<div class="panel-body">

<div class="list-group">
<a href="#" class="list-group-item active">
  GENERAL INFORMASI
</a>
<a href="#" class="list-group-item"><span class="fa fa-certificate"></span> &nbsp;<?php echo $nik;?></a>
<a href="#" class="list-group-item"><span class="glyphicon glyphicon-user"></span> &nbsp;<?php echo $nama;?></a>
<a href="#" class="list-group-item"><span class="fa fa-address-card"></span> &nbsp;<?php echo $alamat;?></a>
<a href="#" class="list-group-item"><span class="fa fa-venus-mars"></span> &nbsp;<?php echo $jk;?></a>
</div>



</div>


<div class="panel-body">

<div class="list-group">
<a href="#" class="list-group-item active">
  BUSSINES INFORMASI
</a>
<a href="#" class="list-group-item"><span class="fa fa-certificate"></span> &nbsp;<?php echo $dept;?></a>
<a href="#" class="list-group-item"><span class="fa fa-th-large"></span> &nbsp;<?php echo $bagian;?></a>
<a href="#" class="list-group-item"><span class="fa fa-briefcase"></span> &nbsp;<?php echo $jabatan;?></a>
<a href="#" class="list-group-item"><span class="fa fa-leaf"></span> &nbsp;<?php echo $level;?></a>
</div>



</div>


</div>
</div>

</div><!--/.row-->	


