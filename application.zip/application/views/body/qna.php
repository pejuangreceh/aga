		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Informasi</h1>
			</div>
		</div><!--/.row-->
		
		
		


		<div class="row">

			<div class="col-xs-12 col-md-12">


				<div class="panel panel-default chat">
					<div class="panel-heading" id="accordion"><i class="fa fa-question-circle glyph stroked male-user"></i> Question & Answer</div>
				
					<div class="panel-body">
						<ul>

							<li class=" clearfix">
								<a href="">
								<div class="chat-body clearfix">
									<b>Prosedur Pengajuan Asuransi Bangunan Nasabah</b>
								</div>
								</a>
							</li>
							<li class=" clearfix">
							<a href="">
								<div class="chat-body clearfix">
									<b>Proses Pengajuan Asuransi Kendaraan Nasabah</b>
								</div>
							</a>
							</li>
							<li class=" clearfix">
							<a href="">
								<div class="chat-body clearfix">
									<b>Jika Ingin Mengajukan Refund Premi Milik Nasabah</b>
								</div>
							</li>
							</a>
							<li class=" clearfix">
							<a href="">
								<div class="chat-body clearfix">
									<b>Jika Ingin Mengajukan Pembatalan Asuransi Nasabah</b>
								</div>
							</li>
							</a>
							
						</ul>
					</div>
			</div>
		</div><!--/.row-->
								
		
								
			</div><!--/.col-->
		</div><!--/.row-->
	</div>	<!--/.main-->